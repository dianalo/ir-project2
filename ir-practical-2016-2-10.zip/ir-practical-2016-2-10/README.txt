README
========

To reproduce our results, just run the main function inside class ch.ethz.ir.project2.main
with either argument 
- „-training“, to evaluate our models on the training data
- „-test“, to compute the sent in test results

don’t forget to specify all data paths at the beginning of main() beforehand